# تنظیمات پیشرفته
SETTINGS = {
    'MAX_SPAM_COUNT': 10,
    'SPAM_TIME_WINDOW': 10,
    'DEFAULT_MUTE_DURATION': 60,
    'CLOCK_UPDATE_INTERVAL': 60,
    'MAX_DELETE_MESSAGES': 1000,
    'WELCOME_DELETE_DELAY': 30
}

# پیام‌های سیستم
SYSTEM_MESSAGES = {
    'SPAM_WARNING': '⚠️ شما به دلیل اسپم کردن در {time} ثانیه {count} پیام فرستادید و به مدت {duration} دقیقه سکوت شدید.',
    'SPAM_RELEASED': '✅ شما از سکوت خارج شدید!',
    'UNAUTHORIZED': '❌ شما مجاز به استفاده از این دستور نیستید!',
    'ERROR_OCCURRED': '❌ خطایی رخ داد! لطفاً دوباره تلاش کنید.',
    'SUCCESS': '✅ عملیات با موفقیت انجام شد!',
    'INVALID_INPUT': '❌ ورودی نامعتبر است!'
}