import json
import os
from datetime import datetime
import pytz

def save_data(filename, data):
    """ذخیره داده در فایل JSON"""
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        print(f"خطا در ذخیره {filename}: {e}")
        return False

def load_data(filename, default=None):
    """بارگذاری داده از فایل JSON"""
    try:
        if os.path.exists(filename):
            with open(filename, 'r', encoding='utf-8') as f:
                return json.load(f)
        return default or {}
    except Exception as e:
        print(f"خطا در بارگذاری {filename}: {e}")
        return default or {}

def get_persian_date():
    """دریافت تاریخ شمسی"""
    try:
        import jdatetime
        now = jdatetime.datetime.now()
        return now.strftime('%Y/%m/%d')
    except ImportError:
        return "نیاز به نصب jdatetime"

def format_duration(seconds):
    """فرمت کردن مدت زمان"""
    if seconds < 60:
        return f"{seconds} ثانیه"
    elif seconds < 3600:
        return f"{seconds // 60} دقیقه"
    else:
        return f"{seconds // 3600} ساعت"

def is_admin(user_id, admin_list):
    """بررسی ادمین بودن کاربر"""
    return user_id in admin_list

def clean_text(text):
    """پاک کردن متن از کاراکترهای اضافی"""
    return text.strip().replace('\n', ' ').replace('\r', '')