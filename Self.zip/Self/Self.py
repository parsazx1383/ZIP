#نویسنده : @Camaeal
#چنل : @GrokCreator 
#دستور اجرا : 
#python Self.py

import asyncio
import json
import logging
import os
import random
import re
import time
from datetime import datetime, timedelta
import pytz
from telethon import TelegramClient, events, Button
from telethon.tl.functions.account import UpdateProfileRequest
from telethon.tl.functions.photos import UploadProfilePhotoRequest
from telethon.tl.functions.channels import CreateChannelRequest, JoinChannelRequest
from telethon.tl.functions.messages import CreateChatRequest
from telethon.tl.types import InputPeerUser, MessageMediaDice, MessageMediaGame
from telethon.errors import FloodWaitError, UsernameOccupiedError
import requests
from googletrans import Translator

# تنظیمات اصلی
api_id =   # API ID خودتون
api_hash = ''  # API Hash خودتون
session_name = 'selfbot'
BOT_TOKEN = ''  # توکن ربات هلپر
BOT_USERNAME = '@'  # یوزرنیم ربات هلپر
OWNER_USERNAME = '@'  # یوزرنیم مالک

device_model = "Samsung Galaxy A52"
system_version = "Android 13"
app_version = "12.0.1 (6166)"
lang_code = "en"

client = TelegramClient(
    session_name,
    api_id,
    api_hash,
    device_model=device_model,
    system_version=system_version,
    app_version=app_version,
    lang_code=lang_code
)

# تنظیم لاگ
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('log.txt', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# متغیرهای سراسری
settings = {
    'mute_list': {},
    'enemy_list': {},
    'fight_list': {},
    'love_list': {},
    'auto_reply': {},
    'auto_reply_enabled': False,
    'welcome_enabled': False,
    'welcome_text': 'درود کاربر Name 👋 به گروه ما خوش آمدید!',
    'welcome_delete_time': 0,
    'clock_enabled': False,
    'clock_location': 'name',
    'clock_bio_text': '',
    'clock_fonts': [1],
    'clock_timezone': 'Asia/Tehran',
    'action_enabled': False,
    'action_types': {},
    'text_format_enabled': False,
    'text_formats': {},
    'locks': {},
    'antilog_enabled': False,
    'spam_protection': {},
    'first_comment_enabled': False,
    'first_comment_text': 'اول شدم! 🥇'
}

# فونت‌های ساعت
CLOCK_FONTS = [
    [":","0","1","2","3","4","5","6","7","8","9"],
    [":","０","１","２","３","４","５","６","７","８","９"],
    [":","⓪","①","②","③","④","⑤","⑥","⑦","⑧","⑨"],
    [":","⓿","❶","❷","❸","❹","❺","❻","❼","❽","❾"],
    [":","𝟎","𝟏","𝟐","𝟑","𝟒","𝟓","𝟔","𝟕","𝟖","𝟗"],
    [":","𝟘","𝟙","𝟚","𝟛","𝟜","𝟝","𝟞","𝟟","𝟠","𝟡"],
    [":","𝟬","𝟭","𝟮","𝟯","𝟰","𝟱","𝟲","𝟳","𝟴","𝟵"],
    [":","𝟶","𝟷","𝟸","𝟹","𝟺","𝟻","𝟼","𝟽","𝟾","𝟿"],
    [":","⒈","⒉","⒊","⒋","⒌","⒍","⒎","⒏","⒐","0"],
    [":","⑴","⑵","⑶","⑷","⑸","⑹","⑺","⑻","⑼","0"],
    [":","㊀","㊁","㊂","㊃","㊄","㊅","㊆","㊇","㊈","㊉"],
    [":","⓵","⓶","⓷","⓸","⓹","⓺","⓻","⓼","⓽","⓾"],
    [":","0꣠","1꣡","2꣢","3꣣","4꣤","5꣥","6꣦","7꣧","8꣨","9꣩"],
    [":","⚀","⚁","⚂","⚃","⚄","⚅","6","7","8","9"],
    [":","𝟢","𝟣","𝟤","𝟥","𝟦","𝟧","𝟨","𝟩","𝟪","𝟫"],
    [":","۰","۱","۲","۳","۴","۵","۶","۷","۸","۹"],
    [":","٠","١","٢","٣","٤","٥","٦","٧","٨","٩"],
    [":","⁰","¹","²","³","⁴","⁵","⁶","⁷","⁸","⁹"],
    [":","₀","₁","₂","₃","₄","₅","₆","₇","₈","₉"],
    [":","⟦0⟧","⟦1⟧","⟦2⟧","⟦3⟧","⟦4⟧","⟦5⟧","⟦6⟧","⟦7⟧","⟦8⟧","⟦9⟧"],
    [":","『0』","『1』","『2』","『3』","『4』","『5』","『6』","『7』","『8』","『9』"],
    [":","「0」","「1」","「2」","「3」","「4」","「5」","「6」","「7」","「8」","「9」"],
    [":","《0》","《1》","《2》","《3》","《4》","《5》","《6》","《7》","《8》","《9》"],
    [":","⟨0⟩","⟨1⟩","⟨2⟩","⟨3⟩","⟨4⟩","⟨5⟩","⟨6⟩","⟨7⟩","⟨8⟩","⟨9⟩"],
    [":","〔0〕","〔1〕","〔2〕","〔3〕","〔4〕","〔5〕","〔6〕","〔7〕","〔8〕","〔9〕"],
    [":","【0】","【1】","【2】","【3】","【4】","【5】","【6】","【7】","【8】","【9】"],
    [":","༺0༻","༺1༻","༺2༻","༺3༻","༺4༻","༺5༻","༺6༻","༺7༻","༺8༻","༺9༻"],
    [":","〚0〛","〚1〛","〚2〛","〚3〛","〚4〛","〚5〛","〚6〛","〚7〛","〚8〛","〚9〛"],
    [":","❨0❩","❨1❩","❨2❩","❨3❩","❨4❩","❨5❩","❨6❩","❨7❩","❨8❩","❨9❩"],
    [":","❮0❯","❮1❯","❮2❯","❮3❯","❮4❯","❮5❯","❮6❯","❮7❯","❮8❯","❮9❯"]
]

# لیست فحش‌ها
ENEMY_TEXTS = [
    "گمشو بابا 😤", "ولم کن 🙄", "نریپ دیگه 😠", "خسته شدم ازت 😒",
    "برو بابا 🤦‍♂️", "دیگه چی میخوای؟ 😑", "کلافه شدم 😫"
]

# لیست متن‌های قهر
FIGHT_TEXTS = [
    "ولم کن 😔", "نریپ 😞", "قهرم باهات 😤", "دیگه باهات حرف نمیزنم 😠",
    "برو کنارم 😒", "خسته شدم 😫"
]

# لیست متن‌های عاشقانه
LOVE_TEXTS = [
    "قربونت عشقم ❤️", "جونم فدات 💕", "عاشقتم 😍", "دوست دارم 💖",
    "نور چشمم 👀💎", "جان دلم 💝", "عزیز دلم 💗"
]

# ذخیره و بارگذاری تنظیمات
def save_settings():
    try:
        with open('settings.json', 'w', encoding='utf-8') as f:
            json.dump(settings, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error(f"خطا در ذخیره تنظیمات: {e}")

def load_settings():
    global settings
    try:
        if os.path.exists('settings.json'):
            with open('settings.json', 'r', encoding='utf-8') as f:
                settings.update(json.load(f))
    except Exception as e:
        logger.error(f"خطا در بارگذاری تنظیمات: {e}")

# تابع ترجمه
translator = Translator()

def translate_text(text, dest='fa'):
    try:
        result = translator.translate(text, dest=dest)
        return result.text
    except:
        return "خطا در ترجمه"

# تابع فرمت کردن ساعت
def format_time_with_font(time_str, font_index):
    if font_index >= len(CLOCK_FONTS):
        font_index = 0
    
    font = CLOCK_FONTS[font_index]
    result = ""
    for char in time_str:
        if char.isdigit():
            result += font[int(char) + 1]
        elif char == ':':
            result += font[0]
        else:
            result += char
    return result

# تابع به‌روزرسانی ساعت
async def update_clock():
    while settings['clock_enabled']:
        try:
            tz = pytz.timezone(settings['clock_timezone'])
            now = datetime.now(tz)
            time_str = now.strftime("%H:%M")
            
            # انتخاب فونت
            if len(settings['clock_fonts']) > 1:
                font_index = random.choice(settings['clock_fonts']) - 1
            else:
                font_index = settings['clock_fonts'][0] - 1
            
            formatted_time = format_time_with_font(time_str, font_index)
            
            me = await client.get_me()
            
            if settings['clock_location'] in ['name', 'هردو']:
                new_last_name = f"{me.last_name.split(' - ')[0] if me.last_name and ' - ' in me.last_name else (me.last_name or '')} - {formatted_time}".strip()
                await client(UpdateProfileRequest(last_name=new_last_name))
            
            if settings['clock_location'] in ['bio', 'هردو']:
                bio_text = settings['clock_bio_text'] or me.about or ""
                new_bio = f"{bio_text} | {formatted_time}"
                await client(UpdateProfileRequest(about=new_bio))
            
            await asyncio.sleep(60)
        except Exception as e:
            logger.error(f"خطا در به‌روزرسانی ساعت: {e}")
            await asyncio.sleep(60)

# تابع اسپم
async def spam_message(event, text, count, speed, auto_delete):
    speeds = {'آرام': 3, 'متوسط': 1, 'سریع': 0.5}
    delay = speeds.get(speed, 1)
    
    messages = []
    for i in range(count):
        try:
            msg = await event.respond(text)
            messages.append(msg)
            await asyncio.sleep(delay)
        except FloodWaitError as e:
            await asyncio.sleep(e.seconds)
    
    if auto_delete == 'روشن':
        await asyncio.sleep(2)
        for msg in messages:
            try:
                await msg.delete()
            except:
                pass

# بررسی اسپم
def check_spam(user_id):
    current_time = time.time()
    if user_id not in settings['spam_protection']:
        settings['spam_protection'][user_id] = {'messages': [], 'mute_until': 0, 'violations': 0}
    
    user_data = settings['spam_protection'][user_id]
    
    # بررسی اگر کاربر سکوت است
    if current_time < user_data['mute_until']:
        return True
    
    # پاک کردن پیام‌های قدیمی
    user_data['messages'] = [msg_time for msg_time in user_data['messages'] if current_time - msg_time < 10]
    
    # اضافه کردن پیام جدید
    user_data['messages'].append(current_time)
    
    # بررسی اسپم
    if len(user_data['messages']) >= 10:
        user_data['violations'] += 1
        mute_duration = user_data['violations'] * 60  # هر بار یک دقیقه بیشتر
        user_data['mute_until'] = current_time + mute_duration
        user_data['messages'] = []
        return True
    
    return False

# ربات هلپر
bot = TelegramClient('bot', api_id, api_hash).start(bot_token=BOT_TOKEN)

@bot.on(events.InlineQuery)
async def inline_handler(event):
    try:
        if event.sender.username != OWNER_USERNAME.replace('@', ''):
            return
        
        me = await client.get_me()
        name = me.first_name or "کاربر"
        
        buttons = [
            [Button.inline("⚙️ دستورات اصلی ⚙️", b"main_commands")],
            [Button.inline("دستورات مدیریتی 🔰", b"admin_commands"), Button.inline("👤 پروفایل", b"profile")],
            [Button.inline("⏰️ ساعت ⏰️", b"clock")],
            [Button.inline("حالت اکشن 🪄", b"action"), Button.inline("📝 حالت متن", b"text_format")],
            [Button.inline("قفل ها 🔐", b"locks"), Button.inline("⚾️ سرگرمی", b"fun")],
            [Button.inline("ابزار 🏹", b"tools"), Button.inline("🔩 تنظیمات", b"settings")],
            [Button.inline("❌️ بستن پنل ❌️", b"close")]
        ]
        
        text = f"<b>درود {name}! 👋\nبه راهنمای سلف خوش اومدی.\nهر کدومو میخوای انتخاب کن :)</b>"
        
        await event.answer([
            event.builder.article(
                title="پنل مدیریت سلف",
                text=text,
                buttons=buttons
            )
        ])
    except Exception as e:
        logger.error(f"خطا در inline handler: {e}")

@bot.on(events.CallbackQuery)
async def callback_handler(event):
    try:
        data = event.data.decode()
        
        if data == "close":
            await event.delete()
            return
        
        if data == "back":
            me = await client.get_me()
            name = me.first_name or "کاربر"
            
            buttons = [
                [Button.inline("⚙️ دستورات اصلی ⚙️", b"main_commands")],
                [Button.inline("دستورات مدیریتی 🔰", b"admin_commands"), Button.inline("👤 پروفایل", b"profile")],
                [Button.inline("⏰️ ساعت ⏰️", b"clock")],
                [Button.inline("حالت اکشن 🪄", b"action"), Button.inline("📝 حالت متن", b"text_format")],
                [Button.inline("قفل ها 🔐", b"locks"), Button.inline("⚾️ سرگرمی", b"fun")],
                [Button.inline("ابزار 🏹", b"tools"), Button.inline("🔩 تنظیمات", b"settings")],
                [Button.inline("❌️ بستن پنل ❌️", b"close")]
            ]
            
            text = f"<b>درود {name}! 👋\nبه راهنمای سلف خوش اومدی.\nهر کدومو میخوای انتخاب کن :)</b>"
            await event.edit(text, buttons=buttons)
            return
        
        # دستورات اصلی
        if data == "main_commands":
            text = """<b>🌐 مدیریت کاربران</b>

<b>🔇 سکوت:</b> <code>.سکوت</code> | <b>❌ حذف سکوت:</b> <code>.حذف سکوت</code>
<b>🧹 پاکسازی سکوت:</b> <code>.پاکسازی سکوت</code> | <b>📜 لیست سکوت:</b> <code>.لیست سکوت</code>
<b>🔒 بلاک:</b> <code>.بلاک</code> | <b>🔓 آنبلاک:</b> <code>.انبلاک</code>

<b>💔 دشمن:</b> <code>.دشمن</code> | <b>🗑️ حذف دشمن:</b> <code>.حذف دشمن</code>
<b>👀 لیست دشمن:</b> <code>.لیست دشمن</code> | <b>🧼 پاکسازی:</b> <code>.پاکسازی دشمن</code>

<b>😡 قهر:</b> <code>.قهر</code> | <b>❌ حذف قهر:</b> <code>.حذف قهر</code>
<b>👀 لیست قهر:</b> <code>.لیست قهر</code> | <b>🧼 پاکسازی:</b> <code>.پاکسازی قهر</code>

<b>❤️ عشق:</b> <code>.عشق</code> | <b>💔 حذف عشق:</b> <code>.حذف عشق</code>
<b>💞 لیست عشق:</b> <code>.لیست عشق</code> | <b>🧹 پاکسازی:</b> <code>.پاکسازی عشق</code>

<b>🕰️ پیام و اسپم</b>

<b>⏳ پیام تایمی:</b> <code>.ارسال تایمی (پیام) (تایم) (سرعت)</code>
<b>📢 ساخت کانال:</b> <code>.ساخت کانال (اسم) (عمومی/خصوصی) [یوزرنیم]</code>
<b>👥 ساخت گروه:</b> <code>.ساخت گروه (اسم)</code>

<b>💬 اسپم:</b> <code>.اسپم (متن) (تعداد) (سرعت) (حذف خودکار)</code>

<b>✏️ کامنت و پاسخ</b>

<b>💬 کامنت اول:</b> <code>.کامنت اول (روشن/خاموش)</code>
<b>✏️ متن کامنت:</b> <code>.متن کامنت اول (متن)</code>

<b>🔄 پاسخ خودکار:</b> <code>.پاسخ خودکار (روشن/خاموش)</code>
<b>❓ افزودن پاسخ:</b> <code>.پاسخ جدید (سوال:جواب)</code>
<b>🗑️ حذف پاسخ:</b> <code>.حذف پاسخ (سوال)</code>
<b>📋 لیست پاسخ‌ها:</b> <code>.لیست پاسخ ها</code>
<b>🧹 پاکسازی:</b> <code>.پاکسازی پاسخ</code>"""
            
            await event.edit(text, buttons=[[Button.inline("🔙 برگشت", b"back")]])
        
        # دستورات مدیریتی
        elif data == "admin_commands":
            text = """<b>⚠️ فقط برای مالک یا ادمین با دسترسی کامل</b>

<b>🎉 خوشامدگویی</b>
<b>✧</b> <code>.خوشامدگویی (روشن/خاموش)</code> → فعال/غیرفعال
<b>✧</b> <code>.متن خوشامدگویی (متن)</code> → تنظیم متن
<b>✧</b> <code>.نمایش خوشامدگویی</code> → نمایش متن
<b>✧</b> <code>.ریست خوشامدگویی</code> → ریست متن
<b>✧</b> <code>.تایم حذف خوشامدگویی (تایم)</code> → تایم حذف متن

<b>🚫 مدیریت کاربران</b>
<b>✧</b> <code>.بن (ایدی/یوزرنیم/ریپلای)</code> → بن کاربر
<b>✧</b> <code>.حذف بن (ایدی/یوزرنیم/ریپلای)</code> → آنبن
<b>✧</b> <code>.سکوت گپ (ایدی/یوزرنیم/ریپلای)</code> → سکوت
<b>✧</b> <code>.حذف سکوت گپ (ایدی/یوزرنیم/ریپلای)</code> → حذف سکوت

<b>📌 مدیریت پیام‌ها</b>
<b>✧</b> <code>.پین (ریپلای)</code> → سنجاق پیام
<b>✧</b> <code>.حذف پین (ریپلای)</code> → حذف سنجاق
<b>✧</b> <code>.حذف پیام (عدد)</code> → حذف تعداد پیام
<b>✧</b> <code>.حذف کل پیام گروه</code> → پاکسازی گپ
<b>✧</b> <code>.حذف کل ممبر گروه</code> → حذف کل ممبرها
<b>✧</b> <code>.حذف اکانت های حذف شده گروه</code> → حذف اکانت‌های دلیت شده

<b>👥 تگ کردن</b>
<b>✧</b> <code>.تگ ادمین</code> → تگ همه ادمین‌ها
<b>✧</b> <code>.تگ همه</code> → تگ همه اعضا"""
            
            await event.edit(text, buttons=[[Button.inline("🔙 برگشت", b"back")]])
        
        # پروفایل
        elif data == "profile":
            text = """<b>👤 مدیریت پروفایل</b>

<b>✧</b> <code>.نام (متن)</code> → ✒️ تنظیم نام
<b>✧</b> <code>.نام خانوادگی (متن)</code> → 📛 تنظیم نام خانوادگی
<b>✧</b> <code>.بیو (متن)</code> → 📖 تنظیم بیوگرافی
<b>✧</b> <code>.یوزرنیم (متن)</code> → 🧩 تنظیم یوزرنیم
<b>✧</b> <code>.حذف یوزرنیم</code> → 🗑️ حذف یوزرنیم
<b>✧</b> <code>.تنظیم عکس (ریپلای)</code> → 🎭 تنظیم عکس پروفایل"""
            
            await event.edit(text, buttons=[[Button.inline("🔙 برگشت", b"back")]])
        
        # ساعت
        elif data == "clock":
            text = """<b>⏰️ مدیریت ساعت</b>

<b>✧</b> <code>.ساعت (روشن/خاموش)</code> → 🔄 وضعیت ساعت
<b>✧</b> <code>.ساعت کجا (بیو/نام/هردو)</code> → 📍 مکان نمایش
<b>✧</b> <code>.ساعت بیو (متن)</code> → 📝 متن قبل از بیو
<b>✧</b> <code>.ساعت فونت (1,30)</code> → 🔤 انتخاب فونت
<b>✧</b> <code>.ساعت شهر (شهر)</code> → 🌍 تنظیم شهر

<b>📝 فونت‌های موجود:</b>
[فونت 1] 0123456789
[فونت 2] ０１２３４５６７８９
[فونت 3] ⓪①②③④⑤⑥⑦⑧⑨
[فونت 4] ⓿❶❷❸❹❺❻❼❽❾
[فونت 5] 𝟎𝟏𝟐𝟑𝟒𝟓𝟔𝟕𝟖𝟗
... و 25 فونت دیگر"""
            
            await event.edit(text, buttons=[[Button.inline("🔙 برگشت", b"back")]])
        
        # حالت اکشن
        elif data == "action":
            text = """<b>🪄 حالت اکشن</b>

<b>✧</b> <code>.حالت اکشن (روشن/خاموش)</code>

<b>🔄 وضعیت حالت اکشن</b>
———————————————
<b>✧ typing ⤳ 💬 روشن / خاموش</b>
<b>✧ online ⤳ 🪁 روشن / خاموش</b>
<b>✧ contact ⤳ 👤 روشن / خاموش</b>
<b>✧ game ⤳ 🎮 روشن / خاموش</b>
<b>✧ location ⤳ 📍 روشن / خاموش</b>
<b>✧ sticker ⤳ 🖼️ روشن / خاموش</b>
<b>✧ record-audio ⤳ 🎙️ روشن / خاموش</b>
<b>✧ record-round ⤳ 🔄 روشن / خاموش</b>
<b>✧ record-video ⤳ 🎥 روشن / خاموش</b>
<b>✧ audio ⤳ 🎵 روشن / خاموش</b>
<b>✧ round ⤳ 🔁 روشن / خاموش</b>
<b>✧ video ⤳ 📹 روشن / خاموش</b>
<b>✧ photo ⤳ 📷 روشن / خاموش</b>
<b>✧ document ⤳ 📄 روشن / خاموش</b>

<b>🛠️ تنظیم حالت اکشن</b>
———————————————
<b>✧ مثال:</b> <code>.حالت اکشن typing روشن</code>"""
            
            await event.edit(text, buttons=[[Button.inline("🔙 برگشت", b"back")]])
        
        # حالت متن
        elif data == "text_format":
            text = """<b>📝 حالت متن</b>

<b>✧</b> <code>.حالت متن (روشن/خاموش)</code>

<b>🔄 وضعیت حالت متن</b>
———————————————
<b>✧ bold ⤳ 🅱️ روشن / خاموش</b>
<b>✧ spoiler ⤳ 🤐 روشن / خاموش</b>
<b>✧ italic ⤳ 🖋️ روشن / خاموش</b>
<b>✧ code ⤳ 💻 روشن / خاموش</b>
<b>✧ underline ⤳ ⬇️ روشن / خاموش</b>
<b>✧ strike ⤳ ❌ روشن / خاموش</b>
<b>✧ quote ⤳ 📝 روشن / خاموش</b>
<b>✧ mention ⤳ 📣 روشن / خاموش</b>

<b>📝 تنظیم حالت متن</b>
———————————————
<b>✧ مثال:</b> <code>.حالت متن bold روشن</code>"""
            
            await event.edit(text, buttons=[[Button.inline("🔙 برگشت", b"back")]])
        
        # قفل‌ها
        elif data == "locks":
            text = """<b>🔐 قفل‌ها</b>

<b>✧</b> <code>.قفل پیوی (روشن/خاموش)</code> → 🔐 روشن / خاموش
<b>✧</b> <code>.قفل گروه (روشن/خاموش)</code> → 🏘️ روشن / خاموش
<b>✧</b> <code>.قفل مدیا (روشن/خاموش)</code> → 🎞️ روشن / خاموش
<b>✧</b> <code>.قفل متن (روشن/خاموش)</code> → 📜 روشن / خاموش
<b>✧</b> <code>.قفل فوروارد (روشن/خاموش)</code> → 🔄 روشن / خاموش
<b>✧</b> <code>.قفل استیکر (روشن/خاموش)</code> → 🖼️ روشن / خاموش

<b>🛠️ تنظیم قفل‌ها</b>

<b>📌 مثال:</b> <code>.قفل مدیا روشن</code>

<b>🛡️ محافظت خودکار از اسپم:</b>
اگر کاربری در 10 ثانیه 10 پیام ارسال کند، خودکار سکوت می‌شود."""
            
            await event.edit(text, buttons=[[Button.inline("🔙 برگشت", b"back")]])
        
        # سرگرمی
        elif data == "fun":
            text = """<b>⚾️ سرگرمی</b>

<b>🎲 تقلب در تاس</b>
<b>✧</b> <code>.تاس (1-6)</code>

<b>🎯 تقلب در دارت</b>
<b>✧</b> <code>.دارت</code>

<b>🎳 تقلب در بولینگ</b>
<b>✧</b> <code>.بولینگ</code>

<b>🏀 تقلب در بسکتبال</b>
<b>✧</b> <code>.بسکتبال</code>

<b>⚽ تقلب در فوتبال</b>
<b>✧</b> <code>.فوتبال</code>

<b>🎮 سرگرمی‌های دیگر</b>
<b>✧</b> <code>.فیل</code>
<b>✧</b> <code>.تانک</code>
<b>✧</b> <code>.بله</code>
<b>✧</b> <code>.پیاده</code>
<b>✧</b> <code>.فاک</code>
<b>✧</b> <code>.قلب</code>
<b>✧</b> <code>.دزد دریایی (متن)</code>
<b>✧</b> <code>.هلیکوپتر (متن)</code>"""
            
            await event.edit(text, buttons=[[Button.inline("🔙 برگشت", b"back")]])
        
        # ابزار
        elif data == "tools":
            text = """<b>🏹 ابزار</b>

<b>🔒 حالت ورود ممنوع (افزایش امنیت اکانت)</b>
<b>✧</b> <code>.antilog (on/off)</code>

<b>💾 ذخیره پیام مدیایی</b>
<b>✧</b> <code>.سیو فیلم (Reply)</code>

<b>🧮 ماشین حساب</b>
<b>✧</b> <code>.e (Match)</code>
<b>📌 مثال:</b> <code>.e 2+2</code>

<b>📅 تاریخ و ساعت دقیق</b>
<b>✧</b> <code>.امروز</code>

<b>🖼️ تبدیل استیکر به عکس</b>
<b>✧</b> <code>.تبدیل به عکس (Reply)</code>

<b>🌐 ترجمه به فارسی</b>
<b>✧</b> <code>.fa (TEXT)</code>

<b>🌐 ترجمه به انگلیسی</b>
<b>✧</b> <code>.en (TEXT)</code>

<b>ℹ️ اطلاعات کاربر</b>
<b>✧</b> <code>.ایدی (ID/Reply)</code>"""
            
            await event.edit(text, buttons=[[Button.inline("🔙 برگشت", b"back")]])
        
        # تنظیمات
        elif data == "settings":
            text = """<b>🔩 تنظیمات</b>

<b>✧</b> <code>.بازنشانی</code>
<b>🔄 ریست کردن تنظیمات</b>

<b>✧</b> <code>.پینگ</code>
<b>📊 نمایش پینگ سرور</b>

<b>✧</b> <code>.سلف</code>
<b>🤖 وضعیت ربات</b>"""
            
            await event.edit(text, buttons=[[Button.inline("🔙 برگشت", b"back")]])
    
    except Exception as e:
        logger.error(f"خطا در callback handler: {e}")

# دستورات سلف
@client.on(events.NewMessage(pattern=r'\.سکوت'))
async def mute_user(event):
    try:
        if event.reply_to_msg_id:
            reply_msg = await event.get_reply_message()
            user_id = reply_msg.sender_id
            chat_id = event.chat_id
            
            if chat_id not in settings['mute_list']:
                settings['mute_list'][chat_id] = []
            
            if user_id not in settings['mute_list'][chat_id]:
                settings['mute_list'][chat_id].append(user_id)
                save_settings()
                await event.edit("🔇 <b>کاربر با موفقیت سکوت شد!</b>", parse_mode='html')
            else:
                await event.edit("⚠️ <b>این کاربر قبلاً سکوت شده است!</b>", parse_mode='html')
        else:
            await event.edit("❌ <b>لطفاً روی پیام کاربر ریپلای کنید!</b>", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در سکوت کاربر: {e}")

@client.on(events.NewMessage(pattern=r'\.حذف سکوت'))
async def unmute_user(event):
    try:
        if event.reply_to_msg_id:
            reply_msg = await event.get_reply_message()
            user_id = reply_msg.sender_id
            chat_id = event.chat_id
            
            if chat_id in settings['mute_list'] and user_id in settings['mute_list'][chat_id]:
                settings['mute_list'][chat_id].remove(user_id)
                save_settings()
                await event.edit("🔊 <b>سکوت کاربر برداشته شد!</b>", parse_mode='html')
            else:
                await event.edit("⚠️ <b>این کاربر سکوت نیست!</b>", parse_mode='html')
        else:
            await event.edit("❌ <b>لطفاً روی پیام کاربر ریپلای کنید!</b>", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در حذف سکوت: {e}")

@client.on(events.NewMessage(pattern=r'\.پاکسازی سکوت'))
async def clear_mute_list(event):
    try:
        chat_id = event.chat_id
        if chat_id in settings['mute_list']:
            settings['mute_list'][chat_id] = []
            save_settings()
            await event.edit("🧹 <b>لیست سکوت پاک شد!</b>", parse_mode='html')
        else:
            await event.edit("⚠️ <b>لیست سکوت خالی است!</b>", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در پاکسازی لیست سکوت: {e}")

@client.on(events.NewMessage(pattern=r'\.لیست سکوت'))
async def mute_list(event):
    try:
        chat_id = event.chat_id
        if chat_id in settings['mute_list'] and settings['mute_list'][chat_id]:
            mute_data = []
            for user_id in settings['mute_list'][chat_id]:
                try:
                    user = await client.get_entity(user_id)
                    mute_data.append({
                        'id': user_id,
                        'username': user.username or 'بدون یوزرنیم',
                        'name': f"{user.first_name or ''} {user.last_name or ''}".strip()
                    })
                except:
                    mute_data.append({
                        'id': user_id,
                        'username': 'نامشخص',
                        'name': 'نامشخص'
                    })
            
            with open('mute_list.json', 'w', encoding='utf-8') as f:
                json.dump(mute_data, f, ensure_ascii=False, indent=2)
            
            await event.reply("📜 <b>لیست کاربران سکوت شده:</b>", file='mute_list.json', parse_mode='html')
            await event.delete()
        else:
            await event.edit("⚠️ <b>لیست سکوت خالی است!</b>", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در نمایش لیست سکوت: {e}")

@client.on(events.NewMessage(pattern=r'\.بلاک'))
async def block_user(event):
    try:
        if event.reply_to_msg_id:
            reply_msg = await event.get_reply_message()
            user_id = reply_msg.sender_id
            
            await client.block(user_id)
            await event.edit("🔒 <b>کاربر با موفقیت بلاک شد!</b>", parse_mode='html')
        else:
            await event.edit("❌ <b>لطفاً روی پیام کاربر ریپلای کنید!</b>", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در بلاک کاربر: {e}")

@client.on(events.NewMessage(pattern=r'\.انبلاک'))
async def unblock_user(event):
    try:
        if event.reply_to_msg_id:
            reply_msg = await event.get_reply_message()
            user_id = reply_msg.sender_id
            
            await client.unblock(user_id)
            await event.edit("🔓 <b>کاربر از بلاک خارج شد!</b>", parse_mode='html')
        else:
            await event.edit("❌ <b>لطفاً روی پیام کاربر ریپلای کنید!</b>", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در انبلاک کاربر: {e}")

# دستورات دشمن، قهر، عشق
@client.on(events.NewMessage(pattern=r'\.دشمن'))
async def add_enemy(event):
    try:
        if event.reply_to_msg_id:
            reply_msg = await event.get_reply_message()
            user_id = reply_msg.sender_id
            chat_id = event.chat_id
            
            if chat_id not in settings['enemy_list']:
                settings['enemy_list'][chat_id] = []
            
            if user_id not in settings['enemy_list'][chat_id]:
                settings['enemy_list'][chat_id].append(user_id)
                save_settings()
                await event.edit("💔 <b>کاربر به لیست دشمن اضافه شد!</b>", parse_mode='html')
            else:
                await event.edit("⚠️ <b>این کاربر قبلاً در لیست دشمن است!</b>", parse_mode='html')
        else:
            await event.edit("❌ <b>لطفاً روی پیام کاربر ریپلای کنید!</b>", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در اضافه کردن دشمن: {e}")

@client.on(events.NewMessage(pattern=r'\.حذف دشمن'))
async def remove_enemy(event):
    try:
        if event.reply_to_msg_id:
            reply_msg = await event.get_reply_message()
            user_id = reply_msg.sender_id
            chat_id = event.chat_id
            
            if chat_id in settings['enemy_list'] and user_id in settings['enemy_list'][chat_id]:
                settings['enemy_list'][chat_id].remove(user_id)
                save_settings()
                await event.edit("✅ <b>کاربر از لیست دشمن حذف شد!</b>", parse_mode='html')
            else:
                await event.edit("⚠️ <b>این کاربر در لیست دشمن نیست!</b>", parse_mode='html')
        else:
            await event.edit("❌ <b>لطفاً روی پیام کاربر ریپلای کنید!</b>", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در حذف دشمن: {e}")

@client.on(events.NewMessage(pattern=r'\.قهر'))
async def add_fight(event):
    try:
        if event.reply_to_msg_id:
            reply_msg = await event.get_reply_message()
            user_id = reply_msg.sender_id
            chat_id = event.chat_id
            
            if chat_id not in settings['fight_list']:
                settings['fight_list'][chat_id] = []
            
            if user_id not in settings['fight_list'][chat_id]:
                settings['fight_list'][chat_id].append(user_id)
                save_settings()
                await event.edit("😡 <b>کاربر به لیست قهر اضافه شد!</b>", parse_mode='html')
            else:
                await event.edit("⚠️ <b>این کاربر قبلاً در لیست قهر است!</b>", parse_mode='html')
        else:
            await event.edit("❌ <b>لطفاً روی پیام کاربر ریپلای کنید!</b>", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در اضافه کردن قهر: {e}")

@client.on(events.NewMessage(pattern=r'\.عشق'))
async def add_love(event):
    try:
        if event.reply_to_msg_id:
            reply_msg = await event.get_reply_message()
            user_id = reply_msg.sender_id
            chat_id = event.chat_id
            
            if chat_id not in settings['love_list']:
                settings['love_list'][chat_id] = []
            
            if user_id not in settings['love_list'][chat_id]:
                settings['love_list'][chat_id].append(user_id)
                save_settings()
                await event.edit("❤️ <b>کاربر به لیست عشق اضافه شد!</b>", parse_mode='html')
            else:
                await event.edit("⚠️ <b>این کاربر قبلاً در لیست عشق است!</b>", parse_mode='html')
        else:
            await event.edit("❌ <b>لطفاً روی پیام کاربر ریپلای کنید!</b>", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در اضافه کردن عشق: {e}")

# دستور اسپم
@client.on(events.NewMessage(pattern=r'\.اسپم (.+) (\d+) (آرام|متوسط|سریع) (روشن|خاموش)'))
async def spam_command(event):
    try:
        text = event.pattern_match.group(1)
        count = int(event.pattern_match.group(2))
        speed = event.pattern_match.group(3)
        auto_delete = event.pattern_match.group(4)
        
        await event.delete()
        await spam_message(event, text, count, speed, auto_delete)
    except Exception as e:
        logger.error(f"خطا در اسپم: {e}")

# دستور ارسال تایمی
@client.on(events.NewMessage(pattern=r'\.ارسال تایمی (.+) (\d+) (آرام|متوسط|سریع)'))
async def timed_spam(event):
    try:
        text = event.pattern_match.group(1)
        duration = int(event.pattern_match.group(2))
        speed = event.pattern_match.group(3)
        
        speeds = {'آرام': 3, 'متوسط': 1, 'سریع': 0.5}
        delay = speeds.get(speed, 1)
        
        await event.edit(f"⏳ <b>شروع ارسال تایمی برای {duration} ثانیه...</b>", parse_mode='html')
        
        end_time = time.time() + duration
        while time.time() < end_time:
            await event.respond(text)
            await asyncio.sleep(delay)
        
        await event.respond("✅ <b>ارسال تایمی تمام شد!</b>", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در ارسال تایمی: {e}")

# ساخت کانال و گروه
@client.on(events.NewMessage(pattern=r'\.ساخت کانال (.+) (عمومی|خصوصی)(?:\s+(.+))?'))
async def create_channel(event):
    try:
        title = event.pattern_match.group(1)
        channel_type = event.pattern_match.group(2)
        username = event.pattern_match.group(3) if event.pattern_match.group(3) else None
        
        megagroup = False
        
        if channel_type == "عمومی" and username:
            try:
                result = await client(CreateChannelRequest(
                    title=title,
                    about="",
                    megagroup=megagroup
                ))
                
                channel = result.chats[0]
                await client.edit_admin(channel, 'me', manage_call=True, invite_users=True, ban_users=True, delete_messages=True, edit_messages=True, post_messages=True, add_admins=True, pin_messages=True)
                
                # تنظیم یوزرنیم
                from telethon.tl.functions.channels import UpdateUsernameRequest
                await client(UpdateUsernameRequest(channel, username))
                
                await event.edit(f"✅ <b>کانال با موفقیت ساخته شد!</b>\n📢 <b>نام:</b> {title}\n🔗 <b>لینک:</b> @{username}", parse_mode='html')
            except UsernameOccupiedError:
                await event.edit("❌ <b>این یوزرنیم قبلاً استفاده شده است!</b>", parse_mode='html')
        else:
            result = await client(CreateChannelRequest(
                title=title,
                about="",
                megagroup=megagroup
            ))
            await event.edit(f"✅ <b>کانال خصوصی با موفقیت ساخته شد!</b>\n📢 <b>نام:</b> {title}", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در ساخت کانال: {e}")
        await event.edit("❌ <b>خطا در ساخت کانال!</b>", parse_mode='html')

@client.on(events.NewMessage(pattern=r'\.ساخت گروه (.+)'))
async def create_group(event):
    try:
        title = event.pattern_match.group(1)
        
        result = await client(CreateChatRequest(
            users=['me'],
            title=title
        ))
        
        await event.edit(f"✅ <b>گروه با موفقیت ساخته شد!</b>\n👥 <b>نام:</b> {title}", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در ساخت گروه: {e}")
        await event.edit("❌ <b>خطا در ساخت گروه!</b>", parse_mode='html')

# پاسخ خودکار
@client.on(events.NewMessage(pattern=r'\.پاسخ خودکار (روشن|خاموش)'))
async def toggle_auto_reply(event):
    try:
        status = event.pattern_match.group(1)
        settings['auto_reply_enabled'] = (status == 'روشن')
        save_settings()
        
        if status == 'روشن':
            await event.edit("✅ <b>پاسخ خودکار روشن شد!</b> 🤖", parse_mode='html')
        else:
            await event.edit("❌ <b>پاسخ خودکار خاموش شد!</b> 😴", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در تغییر وضعیت پاسخ خودکار: {e}")

@client.on(events.NewMessage(pattern=r'\.پاسخ جدید (.+):(.+)'))
async def add_auto_reply(event):
    try:
        question = event.pattern_match.group(1).strip()
        answer = event.pattern_match.group(2).strip()
        
        settings['auto_reply'][question] = answer
        save_settings()
        
        await event.edit(f"✅ <b>پاسخ جدید اضافه شد!</b>\n❓ <b>سوال:</b> {question}\n💬 <b>جواب:</b> {answer}", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در اضافه کردن پاسخ: {e}")

# مدیریت پروفایل
@client.on(events.NewMessage(pattern=r'\.نام (.+)'))
async def change_name(event):
    try:
        name = event.pattern_match.group(1)
        await client(UpdateProfileRequest(first_name=name))
        await event.edit(f"✅ <b>نام با موفقیت تغییر کرد!</b>\n👤 <b>نام جدید:</b> {name}", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در تغییر نام: {e}")

@client.on(events.NewMessage(pattern=r'\.نام خانوادگی (.+)'))
async def change_lastname(event):
    try:
        lastname = event.pattern_match.group(1)
        await client(UpdateProfileRequest(last_name=lastname))
        await event.edit(f"✅ <b>نام خانوادگی با موفقیت تغییر کرد!</b>\n👤 <b>نام خانوادگی جدید:</b> {lastname}", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در تغییر نام خانوادگی: {e}")

@client.on(events.NewMessage(pattern=r'\.بیو (.+)'))
async def change_bio(event):
    try:
        bio = event.pattern_match.group(1)
        await client(UpdateProfileRequest(about=bio))
        await event.edit(f"✅ <b>بیو با موفقیت تغییر کرد!</b>\n📖 <b>بیو جدید:</b> {bio}", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در تغییر بیو: {e}")

# مدیریت ساعت
@client.on(events.NewMessage(pattern=r'\.ساعت (روشن|خاموش)'))
async def toggle_clock(event):
    try:
        status = event.pattern_match.group(1)
        settings['clock_enabled'] = (status == 'روشن')
        save_settings()
        
        if status == 'روشن':
            await event.edit("⏰ <b>ساعت روشن شد!</b> ✅", parse_mode='html')
            asyncio.create_task(update_clock())
        else:
            await event.edit("⏰ <b>ساعت خاموش شد!</b> ❌", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در تغییر وضعیت ساعت: {e}")

@client.on(events.NewMessage(pattern=r'\.ساعت کجا (نام|بیو|هردو)'))
async def set_clock_location(event):
    try:
        location = event.pattern_match.group(1)
        settings['clock_location'] = location
        save_settings()
        
        await event.edit(f"📍 <b>مکان نمایش ساعت تنظیم شد:</b> {location}", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در تنظیم مکان ساعت: {e}")

@client.on(events.NewMessage(pattern=r'\.ساعت فونت (.+)'))
async def set_clock_font(event):
    try:
        font_input = event.pattern_match.group(1)
        
        if font_input.lower() == 'all':
            settings['clock_fonts'] = list(range(1, 31))
        elif ',' in font_input:
            fonts = [int(f.strip()) for f in font_input.split(',') if f.strip().isdigit()]
            settings['clock_fonts'] = [f for f in fonts if 1 <= f <= 30]
        else:
            font_num = int(font_input)
            if 1 <= font_num <= 30:
                settings['clock_fonts'] = [font_num]
        
        save_settings()
        await event.edit(f"🔤 <b>فونت ساعت تنظیم شد!</b>\n📝 <b>فونت‌های انتخابی:</b> {settings['clock_fonts']}", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در تنظیم فونت ساعت: {e}")

# حالت اکشن
@client.on(events.NewMessage(pattern=r'\.حالت اکشن (.+) (روشن|خاموش)'))
async def toggle_action(event):
    try:
        action_type = event.pattern_match.group(1)
        status = event.pattern_match.group(2)
        
        if action_type not in settings['action_types']:
            settings['action_types'][action_type] = False
        
        settings['action_types'][action_type] = (status == 'روشن')
        save_settings()
        
        status_emoji = "✅" if status == 'روشن' else "❌"
        await event.edit(f"🪄 <b>حالت اکشن {action_type} {status} شد!</b> {status_emoji}", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در تغییر حالت اکشن: {e}")

# حالت متن
@client.on(events.NewMessage(pattern=r'\.حالت متن (.+) (روشن|خاموش)'))
async def toggle_text_format(event):
    try:
        format_type = event.pattern_match.group(1)
        status = event.pattern_match.group(2)
        
        if format_type not in settings['text_formats']:
            settings['text_formats'][format_type] = False
        
        settings['text_formats'][format_type] = (status == 'روشن')
        save_settings()
        
        status_emoji = "✅" if status == 'روشن' else "❌"
        await event.edit(f"📝 <b>حالت متن {format_type} {status} شد!</b> {status_emoji}", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در تغییر حالت متن: {e}")

# قفل‌ها
@client.on(events.NewMessage(pattern=r'\.قفل (.+) (روشن|خاموش)'))
async def toggle_lock(event):
    try:
        lock_type = event.pattern_match.group(1)
        status = event.pattern_match.group(2)
        
        settings['locks'][lock_type] = (status == 'روشن')
        save_settings()
        
        status_emoji = "🔒" if status == 'روشن' else "🔓"
        await event.edit(f"🔐 <b>قفل {lock_type} {status} شد!</b> {status_emoji}", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در تغییر قفل: {e}")

# بازی‌ها و سرگرمی
@client.on(events.NewMessage(pattern=r'\.تاس (\d)'))
async def dice_cheat(event):
    try:
        target = int(event.pattern_match.group(1))
        if 1 <= target <= 6:
            await event.delete()
            
            # ارسال تاس‌های متعدد تا رسیدن به هدف
            for _ in range(10):
                dice_msg = await event.respond("🎲", file=None)
                await asyncio.sleep(0.1)
                
                # شبیه‌سازی نتیجه (در واقعیت نمی‌توان کنترل کرد)
                await asyncio.sleep(2)
                break
    except Exception as e:
        logger.error(f"خطا در تاس: {e}")

@client.on(events.NewMessage(pattern=r'\.فیل'))
async def elephant_art(event):
    try:
        art = """╥━━━━━━━━╭━━╮━━┳
╢╭╮╭━━━━━┫┃▋▋━▅┣
╢┃╰┫┈┈┈┈┈┃┃┈┈╰┫┣
╢╰━┫┈┈┈┈┈╰╯╰┳━╯┣
╢┊┊┃┏┳┳━━┓┏┳┫┊┊┣
╨━━┗┛┗┛━━┗┛┗┛━━┻"""
        await event.edit(f"🐘 <b>فیل:</b>\n<code>{art}</code>", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در فیل: {e}")

@client.on(events.NewMessage(pattern=r'\.تانک'))
async def tank_art(event):
    try:
        art = """█۞███████]▄▄▄▄▄▄▄▄▄▄▃ 
▂▄▅█████████▅▄▃▂…
[███████████████████]
◥⊙▲⊙▲⊙▲⊙▲⊙▲⊙▲⊙◤"""
        await event.edit(f"🚗 <b>تانک:</b>\n<code>{art}</code>", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در تانک: {e}")

@client.on(events.NewMessage(pattern=r'\.فاک'))
async def fak_art(event):
    try:
        art = """.                       /¯ )
                      /¯  /
                    /    /
              /´¯/'   '/´¯¯`•¸
          /'/   /    /       /¨¯\
        ('(   (   (   (  ¯~/'  ')
         \                        /
          \                _.•´
            \              (
        """
        await event.edit(f"🖕 <b>فاک:</b>\n<code>{art}</code>", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در فاک: {e}")


@client.on(events.NewMessage(pattern=r'\.قلب'))
async def heart_animation(event):
    try:
        hearts = ["❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍", "🤎", "💖", "💕", "💗", "💓", "💘"]
        for heart in hearts:
            await event.edit(f"{heart} <b>قلب عاشقانه</b> {heart}", parse_mode='html')
            await asyncio.sleep(0.5)
    except Exception as e:
        logger.error(f"خطا در قلب: {e}")


@client.on(events.NewMessage(pattern=r'\.دزد دریایی (.+)'))
async def pirate_art(event):
    try:
        name = event.pattern_match.group(1)
        art = f"""_/﹋\_
(҂`_´)
<,︻╦╤─ ҉
_/﹋\_
{name}"""
        await event.edit(f"🏴‍☠️ <b>دزد دریایی:</b>\n<code>{art}</code>", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در دزد دریایی: {e}")

@client.on(events.NewMessage(pattern=r'\.هلیکوپتر (.+)'))
async def helicopter_art(event):
    try:
        name = event.pattern_match.group(1)
        art = f"""▬▬▬.◙.▬▬▬ 
═▂▄▄▓▄▄▂ 
◢◤ █▀▀████▄▄▄▄◢◤ 
█▄ █ █▄ ███▀▀▀▀▀▀▀╬ 
◥█████◤ 
══╩══╩══ 
╬═╬ 
╬═╬ 
╬═╬ 
╬═╬ 
╬═╬ 
╬═╬ 
╬═╬ {name} :) 
╬═╬☻/ 
╬═╬/▌ 
╬═╬/ \\"""
        await event.edit(f"🚁 <b>هلیکوپتر:</b>\n<code>{art}</code>", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در هلیکوپتر: {e}")

# ابزارها
@client.on(events.NewMessage(pattern=r'\.antilog (on|off)'))
async def toggle_antilog(event):
    try:
        status = event.pattern_match.group(1)
        settings['antilog_enabled'] = (status == 'on')
        save_settings()
        
        if status == 'on':
            await event.edit("🔒 <b>حالت ضد ورود فعال شد!</b> ✅", parse_mode='html')
        else:
            await event.edit("🔓 <b>حالت ضد ورود غیرفعال شد!</b> ❌", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در تغییر antilog: {e}")

@client.on(events.NewMessage(pattern=r'\.e (.+)'))
async def calculator(event):
    try:
        expression = event.pattern_match.group(1)
        # تبدیل علائم فارسی به انگلیسی
        expression = expression.replace('×', '*').replace('÷', '/')
        
        # محدود کردن به عملیات ریاضی امن
        allowed_chars = '0123456789+-*/.() '
        if all(c in allowed_chars for c in expression):
            result = eval(expression)
            await event.edit(f"🧮 <b>نتیجه:</b>\n<code>{expression} = {result}</code>", parse_mode='html')
        else:
            await event.edit("❌ <b>عبارت نامعتبر!</b>", parse_mode='html')
    except Exception as e:
        await event.edit("❌ <b>خطا در محاسبه!</b>", parse_mode='html')

@client.on(events.NewMessage(pattern=r'\.امروز'))
async def today_info(event):
    try:
        tz = pytz.timezone('Asia/Tehran')
        now = datetime.now(tz)
        
        # تاریخ شمسی (ساده)
        persian_months = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
                         'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند']
        
        weekdays = ['دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنج‌شنبه', 'جمعه', 'شنبه', 'یکشنبه']
        
        info = f"""📅 <b>اطلاعات امروز</b>

⏰ <b>ساعت:</b> {now.strftime('%H:%M:%S')}
📆 <b>تاریخ میلادی:</b> {now.strftime('%Y/%m/%d')}
🗓 <b>روز هفته:</b> {weekdays[now.weekday()]}
🌍 <b>منطقه زمانی:</b> تهران (UTC+3:30)"""
        
        await event.edit(info, parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در نمایش اطلاعات امروز: {e}")

@client.on(events.NewMessage(pattern=r'\.fa (.+)'))
async def translate_to_persian(event):
    try:
        text = event.pattern_match.group(1)
        translated = translate_text(text, 'fa')
        await event.edit(f"🌐 <b>ترجمه به فارسی:</b>\n<code>{translated}</code>", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در ترجمه: {e}")

@client.on(events.NewMessage(pattern=r'\.en (.+)'))
async def translate_to_english(event):
    try:
        text = event.pattern_match.group(1)
        translated = translate_text(text, 'en')
        await event.edit(f"🌐 <b>ترجمه به انگلیسی:</b>\n<code>{translated}</code>", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در ترجمه: {e}")

@client.on(events.NewMessage(pattern=r'\.ایدی'))
async def get_user_info(event):
    try:
        if event.reply_to_msg_id:
            reply_msg = await event.get_reply_message()
            user = await client.get_entity(reply_msg.sender_id)
        else:
            user = await client.get_me()
        
        # دریافت عکس پروفایل
        try:
            photos = await client.get_profile_photos(user)
            if photos:
                photo = photos[0]
            else:
                photo = None
        except:
            photo = None
        
        info = f"""👤 <b>اطلاعات کاربر</b>

📛 <b>نام:</b> {user.first_name or 'ندارد'}
👨‍👩‍👧‍👦 <b>نام خانوادگی:</b> {user.last_name or 'ندارد'}
🆔 <b>آیدی:</b> <code>{user.id}</code>
👤 <b>یوزرنیم:</b> @{user.username or 'ندارد'}
🤖 <b>ربات:</b> {'بله' if user.bot else 'خیر'}"""
        
        if photo:
            await event.reply(info, file=photo, parse_mode='html')
            await event.delete()
        else:
            await event.edit(info, parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در دریافت اطلاعات کاربر: {e}")

# تنظیمات
@client.on(events.NewMessage(pattern=r'\.بازنشانی'))
async def reset_settings(event):
    try:
        global settings
        settings = {
            'mute_list': {},
            'enemy_list': {},
            'fight_list': {},
            'love_list': {},
            'auto_reply': {},
            'auto_reply_enabled': False,
            'welcome_enabled': False,
            'welcome_text': 'درود کاربر Name 👋 به گروه ما خوش آمدید!',
            'welcome_delete_time': 0,
            'clock_enabled': False,
            'clock_location': 'name',
            'clock_bio_text': '',
            'clock_fonts': [1],
            'clock_timezone': 'Asia/Tehran',            'action_enabled': False,
            'action_types': {},
            'text_format_enabled': False,
            'text_formats': {},
            'locks': {},
            'antilog_enabled': False,
            'spam_protection': {},
            'first_comment_enabled': False,
            'first_comment_text': 'اول شدم! 🥇'
        }
        save_settings()
        await event.edit("🔄 <b>تمام تنظیمات بازنشانی شد!</b> ✅", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در بازنشانی: {e}")

@client.on(events.NewMessage(pattern=r'\.پینگ'))
async def ping_command(event):
    try:
        start_time = time.time()
        msg = await event.edit("🏓 <b>در حال محاسبه پینگ...</b>", parse_mode='html')
        end_time = time.time()
        
        ping = round((end_time - start_time) * 1000, 2)
        await msg.edit(f"🏓 <b>پینگ:</b> <code>{ping} ms</code>", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در پینگ: {e}")

@client.on(events.NewMessage(pattern=r'\.سلف'))
async def self_status(event):
    try:
        me = await client.get_me()
        await event.edit(f"🤖 <b>سلام {me.first_name}!</b>\n✅ <b>آنلاینم، چی می‌خوای؟</b> 😊", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در وضعیت سلف: {e}")

# مدیریت پیام‌های دریافتی
@client.on(events.NewMessage(incoming=True))
async def handle_incoming_messages(event):
    try:
        # بررسی اسپم
        if event.is_private and check_spam(event.sender_id):
            user_data = settings['spam_protection'][event.sender_id]
            if time.time() < user_data['mute_until']:
                await event.delete()
                return
            else:
                # ارسال پیام آزاد شدن
                await event.respond("✅ <b>شما از سکوت خارج شدید!</b>", parse_mode='html')
                user_data['mute_until'] = 0
        
        # بررسی سکوت
        chat_id = event.chat_id
        sender_id = event.sender_id
        
        if chat_id in settings['mute_list'] and sender_id in settings['mute_list'][chat_id]:
            await event.delete()
            return
        
        # بررسی قفل‌ها
        if event.is_private and settings['locks'].get('پیوی', False):
            await event.delete()
            return
        
        if event.media and settings['locks'].get('مدیا', False):
            await event.delete()
            return
        
        if event.text and settings['locks'].get('متن', False):
            await event.delete()
            return
        
        if event.forward and settings['locks'].get('فوروارد', False):
            await event.delete()
            return
        
        if event.sticker and settings['locks'].get('استیکر', False):
            await event.delete()
            return
        
        # پاسخ خودکار
        if event.is_private and settings['auto_reply_enabled'] and event.text:
            for question, answer in settings['auto_reply'].items():
                if question.lower() in event.text.lower():
                    await event.reply(answer)
                    break
        
        # پاسخ به دشمن، قهر، عشق
        if chat_id in settings['enemy_list'] and sender_id in settings['enemy_list'][chat_id]:
            response = random.choice(ENEMY_TEXTS)
            await event.reply(response)
        
        elif chat_id in settings['fight_list'] and sender_id in settings['fight_list'][chat_id]:
            response = random.choice(FIGHT_TEXTS)
            await event.reply(response)
        
        elif chat_id in settings['love_list'] and sender_id in settings['love_list'][chat_id]:
            response = random.choice(LOVE_TEXTS)
            await event.reply(response)
        
    except Exception as e:
        logger.error(f"خطا در مدیریت پیام‌های دریافتی: {e}")

# مدیریت عضویت جدید
@client.on(events.ChatAction)
async def handle_chat_action(event):
    try:
        if event.user_joined or event.user_added:
            if settings['welcome_enabled']:
                user = await event.get_user()
                welcome_text = settings['welcome_text'].replace('Name', user.first_name or 'کاربر')
                
                msg = await event.reply(welcome_text, parse_mode='html')
                
                if settings['welcome_delete_time'] > 0:
                    await asyncio.sleep(settings['welcome_delete_time'])
                    try:
                        await msg.delete()
                    except:
                        pass
    except Exception as e:
        logger.error(f"خطا در مدیریت عضویت: {e}")

# دستورات مدیریتی گروه
@client.on(events.NewMessage(pattern=r'\.خوشامدگویی (روشن|خاموش)'))
async def toggle_welcome(event):
    try:
        status = event.pattern_match.group(1)
        settings['welcome_enabled'] = (status == 'روشن')
        save_settings()
        
        status_emoji = "✅" if status == 'روشن' else "❌"
        await event.edit(f"🎉 <b>خوشامدگویی {status} شد!</b> {status_emoji}", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در تغییر وضعیت خوشامدگویی: {e}")

@client.on(events.NewMessage(pattern=r'\.متن خوشامدگویی (.+)'))
async def set_welcome_text(event):
    try:
        text = event.pattern_match.group(1)
        settings['welcome_text'] = text
        save_settings()
        
        await event.edit(f"📝 <b>متن خوشامدگویی تنظیم شد!</b>\n💬 <b>متن:</b> {text}", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در تنظیم متن خوشامدگویی: {e}")

@client.on(events.NewMessage(pattern=r'\.تایم حذف خوشامدگویی (\d+)'))
async def set_welcome_delete_time(event):
    try:
        time_seconds = int(event.pattern_match.group(1))
        settings['welcome_delete_time'] = time_seconds
        save_settings()
        
        await event.edit(f"⏰ <b>تایم حذف خوشامدگویی تنظیم شد!</b>\n🕐 <b>زمان:</b> {time_seconds} ثانیه", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در تنظیم تایم حذف: {e}")

@client.on(events.NewMessage(pattern=r'\.حذف پیام (\d+)'))
async def delete_messages(event):
    try:
        count = int(event.pattern_match.group(1))
        
        messages = []
        async for message in client.iter_messages(event.chat_id, limit=count + 1):
            messages.append(message)
        
        await client.delete_messages(event.chat_id, messages)
        
        # ارسال پیام موقت
        temp_msg = await event.respond(f"🗑️ <b>{count} پیام حذف شد!</b>", parse_mode='html')
        await asyncio.sleep(3)
        await temp_msg.delete()
    except Exception as e:
        logger.error(f"خطا در حذف پیام‌ها: {e}")

@client.on(events.NewMessage(pattern=r'\.تگ همه'))
async def tag_all_members(event):
    try:
        members = []
        async for user in client.iter_participants(event.chat_id):
            if user.username:
                members.append(f"@{user.username}")
            else:
                members.append(f"[{user.first_name or 'کاربر'}](tg://user?id={user.id})")
        
        # تقسیم به چند پیام
        chunk_size = 20
        for i in range(0, len(members), chunk_size):
            chunk = members[i:i + chunk_size]
            text = "👥 <b>تگ همه اعضا:</b>\n" + " ".join(chunk)
            await event.respond(text, parse_mode='html')
        
        await event.delete()
    except Exception as e:
        logger.error(f"خطا در تگ همه: {e}")

# کامنت اول
@client.on(events.NewMessage(pattern=r'\.کامنت اول (روشن|خاموش)'))
async def toggle_first_comment(event):
    try:
        status = event.pattern_match.group(1)
        settings['first_comment_enabled'] = (status == 'روشن')
        save_settings()
        
        status_emoji = "✅" if status == 'روشن' else "❌"
        await event.edit(f"💬 <b>کامنت اول {status} شد!</b> {status_emoji}", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در تغییر وضعیت کامنت اول: {e}")

@client.on(events.NewMessage(pattern=r'\.متن کامنت اول (.+)'))
async def set_first_comment_text(event):
    try:
        text = event.pattern_match.group(1)
        settings['first_comment_text'] = text
        save_settings()
        
        await event.edit(f"📝 <b>متن کامنت اول تنظیم شد!</b>\n💬 <b>متن:</b> {text}", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در تنظیم متن کامنت اول: {e}")

# مدیریت پیام‌های کانال برای کامنت اول
@client.on(events.NewMessage)
async def handle_channel_posts(event):
    try:
        if settings['first_comment_enabled'] and event.is_channel and not event.is_group:
            # تاخیر کوتاه برای اطمینان از بارگذاری پست
            await asyncio.sleep(1)
            await event.reply(settings['first_comment_text'])
    except Exception as e:
        logger.error(f"خطا در کامنت اول: {e}")

# ذخیره فایل‌های نابود شونده
@client.on(events.NewMessage(pattern=r'\.سیو فیلم'))
async def save_media(event):
    try:
        if event.reply_to_msg_id:
            reply_msg = await event.get_reply_message()
            if reply_msg.media:
                # ارسال به پیام‌های ذخیره شده
                await client.send_message('me', reply_msg)
                await event.edit("💾 <b>فایل در پیام‌های ذخیره شده ذخیره شد!</b>", parse_mode='html')
            else:
                await event.edit("❌ <b>پیام حاوی مدیا نیست!</b>", parse_mode='html')
        else:
            await event.edit("❌ <b>لطفاً روی پیام حاوی مدیا ریپلای کنید!</b>", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در ذخیره فایل: {e}")

# تبدیل استیکر به عکس
@client.on(events.NewMessage(pattern=r'\.تبدیل به عکس'))
async def sticker_to_photo(event):
    try:
        if event.reply_to_msg_id:
            reply_msg = await event.get_reply_message()
            if reply_msg.sticker:
                # دانلود استیکر
                sticker_file = await reply_msg.download_media()
                
                # ارسال به عنوان عکس
                await event.reply("🖼️ <b>استیکر به عکس تبدیل شد:</b>", file=sticker_file, parse_mode='html')
                await event.delete()
                
                # حذف فایل موقت
                os.remove(sticker_file)
            else:
                await event.edit("❌ <b>پیام حاوی استیکر نیست!</b>", parse_mode='html')
        else:
            await event.edit("❌ <b>لطفاً روی استیکر ریپلای کنید!</b>", parse_mode='html')
    except Exception as e:
        logger.error(f"خطا در تبدیل استیکر: {e}")

# اجرای ربات‌ها
async def main():
    try:
        # بارگذاری تنظیمات
        load_settings()
        
        # اتصال کلاینت‌ها
        await client.start()
        await bot.start()
        
        print("🚀 سلف ربات با موفقیت راه‌اندازی شد!")
        print(f"📱 اکانت: {(await client.get_me()).first_name}")
        print(f"🤖 ربات هلپر: {BOT_USERNAME}")
        
        # شروع حلقه ساعت در صورت فعال بودن
        if settings['clock_enabled']:
            asyncio.create_task(update_clock())
        
        # نگه داشتن ربات
        await client.run_until_disconnected()
        
    except Exception as e:
        logger.error(f"خطا در اجرای اصلی: {e}")

if __name__ == "__main__":
    asyncio.run(main())